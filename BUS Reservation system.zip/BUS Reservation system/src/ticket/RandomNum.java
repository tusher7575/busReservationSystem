/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ticket;

import java.util.Arrays;


public class RandomNum {
    
   
    
    public static void main(String[] args) {
        
         String strTNum="";
        
        int x, count=0,ran[]=new int[5],temp;
        
        for (int i = 0;; i++) {
            
           x=(int)((Math.random()*80)+12);
            int dupcount=0;
            for (int j = 0; j < 5; j++) {
                if(ran[j]==x)
                    dupcount++;
                
            }
            if(dupcount==0)
            {ran[count]=x;
            count++;
            }
            
            if(count==5)
                break;
        }
        Arrays.sort(ran);
        for (int i = 0; i <5; i++) {
            
            strTNum+=Integer.toString(ran[i]);
        }
        
         
    }
    
}
